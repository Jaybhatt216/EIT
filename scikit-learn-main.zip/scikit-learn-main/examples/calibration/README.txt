.. _calibration_examples:

Calibration
-----------------------

Examples illustrating the calibration of predicted probabilities of classifiers.
